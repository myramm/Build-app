init:
    $ dexter_clothing_options = ['b_dressed']

init python:


    renpy.image('dexter_arms_a_empty', 'ground.png')
    renpy.image('dexter_body_b_empty', 'ground.png')
    renpy.image('dexter_face_f_empty', 'ground.png')
    renpy.image('dexter_face_talk_f_empty', 'ground.png')


    renpy.image('dexter_face_talk_f_laugh', 'dexter_face_f_laugh')
    renpy.image('dexter_face_talk_f_surprised_down', 'dexter_face_f_surprised_down')



layeredimage dexter:

    yanchor config.screen_height
    ypos 1.
    xanchor config.screen_width
    xpos 1.


    group body auto:
        attribute b_dressed default
        attribute b_empty null


    group mouth prefix 'm':
        attribute talk null

    group face:
        attribute f_normal default null







    group face if_not 'm_talk' if_any dexter_clothing_options auto











    group face if_all 'm_talk' if_any dexter_clothing_options auto variant 'talk'







    group arms if_all 'b_dressed' auto variant 'dressed':
        attribute a_idle default 'dexter_arms_dressed_a_ball_crotch'






    group overlay auto:
        attribute o_empty default null

image dexter_f = "characters/dexter/layeredimage/dexter_face_f_normal.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
