============================================================
SUMMERTIME SAGA v0.20.16 - BAHASA INDONESIA TRANSLATION PACK
============================================================

Paket ini berisi file script yang sudah diterjemahkan secara lengkap 
ke dalam Bahasa Indonesia untuk Summertime Saga versi 0.20.16 (Stable).

Struktur di dalam ZIP ini:
------------------------------------------------------------
1. folder 'scripts/'
   Berisi seluruh script dialog (.rpy) hasil terjemahan lengkap.
   
CARA PENGGUNAAN (Pilih salah satu sesuai kebutuhanmu):
------------------------------------------------------------
METODE A: Build Ulang APK (Rebuild APK / MT Manager / GitHub Action)
1. Buka project APK Summertime Saga Anda.
2. Timpa (replace) folder 'scripts/' yang ada di dalam direktori 
   'game/scripts/' atau 'assets/x-game/x-scripts/' dengan folder 'scripts/' 
   dari ZIP ini.
3. Build dan sign APK Anda.
4. Game akan langsung berjalan dalam Bahasa Indonesia!

METODE B: Pemasangan Langsung di Android (Tanpa Build Ulang APK)
1. Install APK Summertime Saga v0.20.16 resmi di HP Android Anda.
2. Buka aplikasi File Manager (ZArchiver / MT Manager).
3. Buat/buka folder:
   Android/data/com.kompasproductions.summertimesaga/files/game/
4. Ekstrak isi folder 'scripts/' dari ZIP ini ke dalam folder 'game/' di atas.
5. Buka game dan nikmati permainannya dalam Bahasa Indonesia!

============================================================
Selamat bermain!
============================================================
